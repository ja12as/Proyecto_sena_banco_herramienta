import { z } from "zod";

export const InstructoresSchemas = z.object({
  nombre: z.string({
    required_error: "El nombre del instructor es necesario",
  }),
  correo: z.string({
    required_error: "El correo sena del instructor es necesario",
  }),
  EstadoId: z.number({
    required_error: "El estado del instructor es necesario",
  }),
  celular: z.number({
    required_error: "El número de celular del instructor es necesario",
  }),
});
